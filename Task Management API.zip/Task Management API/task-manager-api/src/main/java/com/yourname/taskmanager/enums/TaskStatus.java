package com.yourname.taskmanager.enums;

public enum TaskStatus {
    PENDING, IN_PROGRESS, COMPLETED, CANCELLED
}
