package com.yourname.taskmanager.enums;

public enum Priority {
    LOW, MEDIUM, HIGH
}
