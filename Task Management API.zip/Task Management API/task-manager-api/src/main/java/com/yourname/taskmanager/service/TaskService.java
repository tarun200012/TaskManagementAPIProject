package com.yourname.taskmanager.service;

import com.yourname.taskmanager.dto.TaskRequestDto;
import com.yourname.taskmanager.dto.TaskResponseDto;
import com.yourname.taskmanager.entity.Task;
import com.yourname.taskmanager.enums.TaskStatus;
import com.yourname.taskmanager.exception.TaskNotFoundException;
import com.yourname.taskmanager.repository.TaskRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class TaskService {

    private final TaskRepository repository;

    public TaskService(TaskRepository repository) {
        this.repository = repository;
    }

    public TaskResponseDto create(TaskRequestDto req) {
        Task t = new Task();
        t.setTitle(req.getTitle());
        t.setDescription(req.getDescription());
        t.setStatus(req.getStatus());
        t.setPriority(req.getPriority());
        t.setDueDate(req.getDueDate());
        Task saved = repository.save(t);
        return toDto(saved);
    }

    @Transactional(readOnly = true)
    public TaskResponseDto getById(Long id) {
        Task t = repository.findById(id)
                .orElseThrow(() -> new TaskNotFoundException(id));
        return toDto(t);
    }

    @Transactional(readOnly = true)
    public List<TaskResponseDto> getAll(TaskStatus status) {
        List<Task> list = (status == null) ? repository.findAll() : repository.findByStatus(status);
        return list.stream().map(this::toDto).collect(Collectors.toList());
    }

    public TaskResponseDto update(Long id, TaskRequestDto req) {
        Task t = repository.findById(id)
                .orElseThrow(() -> new TaskNotFoundException(id));
        t.setTitle(req.getTitle());
        t.setDescription(req.getDescription());
        t.setStatus(req.getStatus());
        t.setPriority(req.getPriority());
        t.setDueDate(req.getDueDate());
        return toDto(t);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new TaskNotFoundException(id);
        }
        repository.deleteById(id);
    }

    private TaskResponseDto toDto(Task t) {
        TaskResponseDto dto = new TaskResponseDto();
        dto.setId(t.getId());
        dto.setTitle(t.getTitle());
        dto.setDescription(t.getDescription());
        dto.setStatus(t.getStatus());
        dto.setPriority(t.getPriority());
        dto.setDueDate(t.getDueDate());
        dto.setCreatedAt(t.getCreatedAt());
        dto.setUpdatedAt(t.getUpdatedAt());
        return dto;
    }
}
