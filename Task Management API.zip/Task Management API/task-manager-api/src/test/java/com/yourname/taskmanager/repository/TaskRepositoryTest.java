package com.yourname.taskmanager.repository;

import com.yourname.taskmanager.entity.Task;
import com.yourname.taskmanager.enums.Priority;
import com.yourname.taskmanager.enums.TaskStatus;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
class TaskRepositoryTest {

    @Autowired
    private TaskRepository repository;

    @Test
    void saveAndFindByStatus() {
        Task t = new Task();
        t.setTitle("Repo test");
        t.setDescription("Testing repository");
        t.setStatus(TaskStatus.PENDING);
        t.setPriority(Priority.MEDIUM);
        t.setDueDate(LocalDate.now().plusDays(2));
        repository.save(t);

        List<Task> pending = repository.findByStatus(TaskStatus.PENDING);
        assertThat(pending).isNotEmpty();
        assertThat(pending.get(0).getTitle()).isEqualTo("Repo test");
    }
}
