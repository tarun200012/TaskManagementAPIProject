package com.yourname.taskmanager.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.yourname.taskmanager.dto.TaskRequestDto;
import com.yourname.taskmanager.enums.Priority;
import com.yourname.taskmanager.enums.TaskStatus;
import com.yourname.taskmanager.service.TaskService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.time.LocalDate;

@WebMvcTest(TaskController.class)
class TaskControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private TaskService service;

    @Test
    void createTask_Valid_Returns201() throws Exception {
        TaskRequestDto req = new TaskRequestDto();
        req.setTitle("Complete Spring Boot Assignment");
        req.setDescription("Build a task management API");
        req.setStatus(TaskStatus.PENDING);
        req.setPriority(Priority.HIGH);
        req.setDueDate(LocalDate.now().plusDays(1));

        Mockito.when(service.create(Mockito.any())).thenAnswer(invocation -> {
            var r = new com.yourname.taskmanager.dto.TaskResponseDto();
            r.setId(1L);
            r.setTitle(req.getTitle());
            r.setDescription(req.getDescription());
            r.setStatus(req.getStatus());
            r.setPriority(req.getPriority());
            r.setDueDate(req.getDueDate());
            return r;
        });

        mockMvc.perform(post("/api/tasks")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(header().string("Location", "/api/tasks/1"))
                .andExpect(jsonPath("$.id").value(1));
    }

    @Test
    void createTask_Invalid_Returns400() throws Exception {
    	String body = "{ \"title\": \"Hi\", \"status\": \"INVALID_STATUS\" }";

        mockMvc.perform(post("/api/tasks")
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
                .andExpect(status().isBadRequest());
    }
}
